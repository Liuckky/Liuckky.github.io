// Tema claro/escuro. Este arquivo é carregado no <head>, então o tema é aplicado antes da página aparecer.
(function () {
  var guardado = null;
  try { guardado = localStorage.getItem("tema"); } catch (e) {}
  var tema = guardado || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  document.documentElement.setAttribute("data-bs-theme", tema);

  document.addEventListener("DOMContentLoaded", function () {
    var botao = document.getElementById("btnTema");
    var ingles = document.documentElement.lang === "en";

    function atualizarRotulo() {
      var escuro = document.documentElement.getAttribute("data-bs-theme") === "dark";
      botao.textContent = ingles ? (escuro ? "Light" : "Dark") : (escuro ? "Claro" : "Escuro");
    }

    atualizarRotulo();
    botao.addEventListener("click", function () {
      var novo = document.documentElement.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-bs-theme", novo);
      try { localStorage.setItem("tema", novo); } catch (e) {}
      atualizarRotulo();
    });
  });
})();
