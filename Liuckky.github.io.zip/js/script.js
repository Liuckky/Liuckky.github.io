const ingles = document.documentElement.lang === "en";

// 1. Ano atual no rodapé
document.getElementById("ano").textContent = new Date().getFullYear();

// 2. Botão "voltar ao topo": aparece depois de rolar a página
const btnTopo = document.getElementById("btnTopo");
window.addEventListener("scroll", function () {
  btnTopo.style.display = window.scrollY > 300 ? "block" : "none";
});
btnTopo.addEventListener("click", function () {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// 3. Formulário de contato (só existe na página de contato)
const form = document.getElementById("formContato");
if (form) {
  form.addEventListener("submit", function (evento) {
    evento.preventDefault();

    const nome = document.getElementById("nome");
    const email = document.getElementById("email");
    const mensagem = document.getElementById("mensagem");
    const retorno = document.getElementById("retorno");

    const nomeOk = nome.value.trim().length >= 2;
    const emailOk = /^\S+@\S+\.\S+$/.test(email.value.trim());
    const mensagemOk = mensagem.value.trim().length >= 10;

    nome.classList.toggle("is-invalid", !nomeOk);
    email.classList.toggle("is-invalid", !emailOk);
    mensagem.classList.toggle("is-invalid", !mensagemOk);

    if (!(nomeOk && emailOk && mensagemOk)) {
      retorno.className = "text-danger";
      retorno.textContent = ingles ? "Fix the highlighted fields." : "Corrija os campos destacados.";
      return;
    }

    retorno.className = "text-success";
    retorno.textContent = ingles ? "Opening your email app..." : "Abrindo o seu programa de email...";
    const assunto = encodeURIComponent((ingles ? "Portfolio contact: " : "Contato pelo portfólio: ") + nome.value.trim());
    const corpo = encodeURIComponent(mensagem.value.trim() + "\n\n" + nome.value.trim() + " (" + email.value.trim() + ")");
    window.location.href = "mailto:" + form.dataset.destino + "?subject=" + assunto + "&body=" + corpo;
    form.reset();
  });
}
